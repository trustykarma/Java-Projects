package battle;
import info.gridworld.grid.Location;

/**
 * This BattleBug moves in random directions.
 * 
 * @author tpolk
 *
 */
public class BattleBugPolk extends AbstractBattleBug {
	
	@Override
	protected void setBattleBugDirection() {
		Location next = getLocation().getAdjacentLocation(getDirection());
		int counter=0;
		boolean validDirection = false;;
		while(! validDirection && counter<25){
			setDirection(getDirection() + (int)(Math.random()*8)*45);
			next = getLocation().getAdjacentLocation(getDirection());
			validDirection = getGrid().isValid(next) && canMove();
			counter++;
		}
	}

	@Override
	protected String getName() {
		return "Polk";
	}

}
