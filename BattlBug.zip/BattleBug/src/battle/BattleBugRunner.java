package battle;
import java.awt.Color;

import info.gridworld.actor.Actor;
import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Rock;
import info.gridworld.grid.BoundedGrid;
import info.gridworld.grid.Location;

/**
 * This class sets up a 20 X 20 grid and puts in two BatleBugs (in opposite corners) that will
 * compete to see who can produce the most rocks before not being able to move.
 * 
 * @author tpolk
 *
 */
public class BattleBugRunner {

	public static void main(String[] args) {
        ActorWorld world = new ActorWorld();
        world.setGrid(new BoundedGrid<Actor>(9, 9));
		int row = (int)(Math.random()*9);
		int col = (int)(Math.random()*9);

        
        Location loc = new Location(row, col);
        AbstractBattleBug bb = new BattleBugPolk();
        bb.setColor(Color.GREEN);
        world.add(loc, bb);

        int newRow = row;
        int newCol = col;

        while (newRow == row && newCol == col){
            newRow = (int)(Math.random()*9);
            newCol = (int)(Math.random()*9);
        }
        loc = new Location(newRow,newCol);
        
        bb = new BattleBugdDongdong();
        bb.setColor(Color.RED);
        world.add(loc,bb);
        world.show();
	}

}
