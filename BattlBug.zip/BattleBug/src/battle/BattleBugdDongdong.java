package battle;
import info.gridworld.grid.Location;

public class BattleBugdDongdong extends AbstractBattleBug {

		@Override
		protected void setBattleBugDirection() {
			Location next = getLocation().getAdjacentLocation(getDirection());
			int counter=0;
			boolean validDirection = getGrid().isValid(next) && canMove();
			while(! validDirection && counter<8){
				setDirection(getDirection() + Location.HALF_LEFT);
				next = getLocation().getAdjacentLocation(getDirection());
				validDirection = getGrid().isValid(next) && canMove();
				counter++;
			}
		}

		@Override
		protected String getName() {
			return "Dongdong";
		}

	}

