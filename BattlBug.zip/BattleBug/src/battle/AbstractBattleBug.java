package battle;
import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Flower;
import info.gridworld.actor.Rock;
import info.gridworld.grid.Grid;
import info.gridworld.grid.Location;

public abstract class AbstractBattleBug extends Bug {
	private Rock aRock = null;
	private int rockCounter = 0;
	
	protected abstract String getName();
	
	
	private int getRockCounter() {
		return rockCounter;
	}
	private void setRockCounter(int rockCounter) {
		this.rockCounter = rockCounter;
	}
	
	@Override
	public void act() {
		setBattleBugDirection();
		if(canMove()){
			move();
		}else{
			removeSelfFromGrid();
			StringBuffer buf = new StringBuffer();
			buf.append("Final rock count for ");
			buf.append(getName());
			buf.append(": ");
			buf.append(getRockCounter());
			System.out.println(buf);
		}
	}
	
   @Override
	public void move()
    {
        Grid<Actor> gr = getGrid();
        if (gr == null)
            return;
        Location loc = getLocation();
        Location next = loc.getAdjacentLocation(getDirection());
        if (gr.isValid(next)){
            moveTo(next);
        }
        aRock=new Rock(getColor());
        aRock.putSelfInGrid(gr,loc);
        setRockCounter(getRockCounter() +1);
    }

	
	protected abstract void setBattleBugDirection();
}
