package array;

import java.util.Scanner;
/**
 * 
 * @author lidongdong
 *
 */
public class RestaurantManagement {
	
	/*********** CLASS VARIABLES **********************************************/
	private String[] restaurants; // the array used to store the restaurants' name
	private int count=0; // the total number of the restaurants
	private Scanner scanner; // the scanner handle all the user input
	
	/*********** GETTERS AND SETTERS *****************************************/
	public String[] getRestaurants() {
		return restaurants;
	}

	public void setRestaurants(String[] restaurants) {
		this.restaurants = restaurants;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public Scanner getScanner() {
		//using lazy initialization
		if(scanner==null)
			scanner=new Scanner(System.in);
		return scanner;
	}

	public void setScanner(Scanner s) {
		this.scanner = s;
	}

	public RestaurantManagement(){
		System.out.println("How many restaurants to you want to store?");
		int size=0; // the initial size of the array
		size=getScanner().nextInt(); // get input from user
		if (size <= 0) {
			System.out.println("Invalid input. The program will quit.");
			System.exit(0);
		}
		
		setRestaurants(new String[size]);
		
		getScanner().nextLine(); // used to kill the extra '\n' 
		
		
		for(int i=0;i<size;i++){
			System.out.println("Restaurant "+(i+1)+": ");
			restaurants[i]=getScanner().nextLine();
			setCount(getCount()+1); // same as count++, but a more formal way
		}
	}
	
	/**
	 * Displays the number of restaurants and the size of the arrray
	 */
	private void size(){
		System.out.println("Method not yet implemented");
	}
	
	/**
	 * First checks to see if there is more capacity in the restaurants array.  If there
	 * is, it adds the String passed in to the next available slot and updates the
	 * count parameter.  If there are no more slots left in the array, call
	 * the resize method to increase it.  Then, add the String to the 
	 * restaurants array and update the count.
	 *  
	 * @param s: the name of the restaurant
	 * 
	 */
	private void add(String s){
		System.out.println("Method not yet implemented");
	}
	/**
	 *  Help the user to add multiple restaurants
	 */
	public void add(){
		System.out.println("How many restaurants do you want to add?");
		int n=0;
		n=getScanner().nextInt();
		if(n<=0)
		{	System.out.println("Invalid number.");
			add(); // will recursively call the method until there is a valid input
			return;
		}
		scanner.nextLine(); // kill the extra '\n'
		for(int i=1;i<=n;i++){
			System.out.println("Restaurant "+i+": ");
			add(getScanner().nextLine());
		}
	}
	
	/**
	 *  This method doubles the size of the array by making a new array and copying the existing 
	 *  values into it.
	 */
	private void resize(){
		System.out.println("Method not yet implemented");
	}
	
	/**
	 * list all the restaurants stored in the system
	 */
	public void list(){
		if(getCount()==0){
			System.out.println("It is empty.");
		}else{
			System.out.println("Method is not yet implemented");
		}
	}
	
	/**
	 * Insert a restaurant in a particular spot
	 */
	public void insert(){
		if(getCount() == getRestaurants().length)
			resize();
		
		System.out.println("Please input the index you want to insert restaurant. Start from 1:");
		int index=getScanner().nextInt()-1;
		if(!(index>=0 && index<getCount())) // check if the index is valid
		{
			System.out.println("Invalid index");
			return;
		}
		System.out.println("Please input the name of the restaurant: ");
		getScanner().nextLine();
		String name=getScanner().nextLine();
		insert(index, name);	
	}
	
	/**
	 * Inserts the restaurant name passed in into the index position passed in. 
	 * All items must first be shifted to the right by one before inserting the 
	 * new item. The count should also be updated to reflect the newly 
	 * inserted item.  Assumes index passed in is valid.
	 * 
	 * @param index
	 * @param restaurantName
	 */
	private void insert(int index, String restaurantName){
		System.out.println("Method not yet implemented");
	}
	
	/**
	 *  Delete the restaurant at the 
	 */
	public void delete(){
		if(count==0){
			System.out.println("There're no more restaurants.");
		}else{
			System.out.println("Please input the index of restaurant you want to delete, start from 1");
			int index=0;
			index=getScanner().nextInt()-1;
			if(index<0 || index>=count) {			
				System.out.println("Invalid index");
			}else{
				//we have a valid index...delete the restaurant
				delete(index);
			}
		}
	}
	
	/**
	 * Deletes the restaurant at the specified index and shifts all remaining restaurants 
	 * to the left.  Also updates the count variable accordingly.  Assumes index passed in is valid.
	 * @param index
	 */
	private void delete(int index){
		System.out.println("Method not implemented yet");
	}
	/**
	 * show the user interface to the user
	 */
	public void showMenu(){
		String input="";
		while(true){ // constantly show this until exit is chosen
			System.out.println("-----------------------------------------");
			System.out.println("Please select from the following options:");
			System.out.println("A: add more");
			System.out.println("S: print the number of the restaurants");
			System.out.println("L: list all the restaurants");
			System.out.println("I: insert a restaurant");
			System.out.println("D: delete one particular restaurant");
			System.out.println("X: exit");
			System.out.println("-----------------------------------------");
			input=scanner.next();
			
		
			switch (input.trim().toLowerCase()) {
			case "x":
				System.out.println("Bye!");
				return;
			case "a":
				this.add();
				continue;
			case "s":
				this.size();
				continue;
			case "l":
				this.list();
				continue;
			case "i":
				this.insert();
				continue;
			case "d":
				this.delete();
				continue;
			default:
				continue;
			}
		}
	}
	
	
}
