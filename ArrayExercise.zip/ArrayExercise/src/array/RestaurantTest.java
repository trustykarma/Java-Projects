package array;

import java.util.Scanner;

public class RestaurantTest {
	public static void main(String[] args) {

		RestaurantManagement restaurantManagement=new RestaurantManagement();
		restaurantManagement.showMenu();
	}
}
