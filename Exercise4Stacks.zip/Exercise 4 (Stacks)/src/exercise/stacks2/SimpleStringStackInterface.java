package exercise.stacks2;

public interface SimpleStringStackInterface {
	/**
	 * Pushes the String passed in onto the top of the stack.
	 * @param s
	 */
	public void push(String s);
	/**
	 * Removes the topmost String from the stack and returns it.
	 * @return topmost String element
	 */
	public String pop();
	/**
	 * Returns the topmost String from the stack without removing it.
	 * @return topmost String element
	 */
	public String peek();
	/**
	 * Returns the number of items in the stack.
	 * @return number of items in the stack
	 */
	public int size();
	/**
	 * Returns true if the stack is empty
	 * @return true if thr stack is empty
	 */
	public boolean isEmpty();
	
}
