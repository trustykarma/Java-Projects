package exercise.stacks3;


public class SimpleGenericStackTester {
	
	public void stringTest(){
		//Push a few items onto the Stack and then push them off and print them
		SimpleGenericStackInterface<String> stack = new SimpleGenericArrayListStack<String>();
		stack.push("badges!");
		stack.push("stinking");
		stack.push("no");
		stack.push("need");
		stack.push("don't");
		stack.push("We");
		stack.push("Badges?");
		
		while (! stack.isEmpty()){
			System.out.println(stack.pop());
		}
	}
	public void studentTest(){
		//Push a few items onto the Stack and then push them off and print them
		SimpleGenericStackInterface<Student> stack = new SimpleGenericArrayListStack<Student>();
		stack.push(new Student("Frank", "Mallory", new Integer(800123456)));
		stack.push(new Student("Jessica", "Perkins", new Integer(800348456)));
		stack.push(new Student("Tyler", "Johnson", new Integer(800846351)));
		stack.push(new Student("Missy", "Cartwright", new Integer(800439812)));
		stack.push(new Student("Ashley", "Crandall", new Integer(800278432)));
		
		while (! stack.isEmpty()){
			System.out.println(stack.pop());
		}
	}

	public static void main(String[] args) {
		SimpleGenericStackTester test = new SimpleGenericStackTester();
		test.stringTest();
		System.out.println();
		test.studentTest();

	}

}
