package exercise.stacks1;

public class SimpleStringStackTester {
	
	public void test(){
		//Push a few items onto the Stack and then push them off and print them
		SimpleStringStackInterface stack = new SimpleStringArrayListStack();
		stack.push("badges!");
		stack.push("stinking");
		stack.push("no");
		stack.push("need");
		stack.push("don't");
		stack.push("We");
		stack.push("Badges?");
		
		while (! stack.isEmpty()){
			System.out.println(stack.pop());
		}
	}

	public static void main(String[] args) {
		SimpleStringStackTester test = new SimpleStringStackTester();
		test.test();

	}

}
